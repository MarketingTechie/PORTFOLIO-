import Hero from '@/components/Hero'
import Expertise from '@/components/Expertise'
import Journey from '@/components/Journey'
import AIIntegration from '@/components/AIIntegration'
import Footer from '@/components/Footer'

export default function Home() {
  return (
    <main>
      <Hero />
      <Expertise />
      <Journey />
      <AIIntegration />
      <Footer />
    </main>
  )
}
