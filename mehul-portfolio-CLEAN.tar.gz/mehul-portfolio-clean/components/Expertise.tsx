'use client'

import { motion } from 'framer-motion'
import { RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer } from 'recharts'

const skillData = [
  { skill: 'Social Media', strength: 95 },
  { skill: 'Digital Systems', strength: 90 },
  { skill: 'Content Strategy', strength: 88 },
  { skill: 'AI Tools', strength: 85 },
  { skill: 'Analytics', strength: 82 },
  { skill: 'SEO & Paid', strength: 78 },
  { skill: 'Email Marketing', strength: 75 },
  { skill: 'Leadership', strength: 80 },
  { skill: 'Video Content', strength: 77 },
]

const skillCategories = [
  {
    title: 'Primary Strengths',
    skills: [
      'Social Media Management',
      'Digital Marketing Systems',
      'Content Strategy & Branding',
    ],
  },
  {
    title: 'Strategic Capabilities',
    skills: [
      'AI Marketing Tools',
      'Marketing Analytics (Power BI)',
      'SEO & Paid Media Fundamentals',
    ],
  },
  {
    title: 'Support Skills',
    skills: [
      'Email Marketing',
      'Leadership & Team Coordination',
      'Video Editing & Visual Content Design',
    ],
  },
]

export default function Expertise() {
  return (
    <section id="expertise" className="py-32 bg-gradient-to-b from-cream to-white">
      <div className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-light mb-4 text-slate-900">
            Core Expertise
          </h2>
          <p className="text-lg text-slate-600 font-sans">
            A visual map of capabilities across the marketing spectrum
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="glass-card p-8 lg:p-12"
          >
            <ResponsiveContainer width="100%" height={400}>
              <RadarChart data={skillData}>
                <PolarGrid stroke="#CBD5E1" strokeWidth={1} />
                <PolarAngleAxis
                  dataKey="skill"
                  tick={{ fill: '#64748B', fontSize: 12, fontFamily: 'var(--font-sans)' }}
                  strokeWidth={0}
                />
                <Radar
                  dataKey="strength"
                  stroke="#4F7CAC"
                  fill="#4F7CAC"
                  fillOpacity={0.2}
                  strokeWidth={2}
                />
              </RadarChart>
            </ResponsiveContainer>
          </motion.div>

          <div className="space-y-8">
            {skillCategories.map((category, idx) => (
              <motion.div
                key={category.title}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.1 * idx }}
                className="glass-card p-6"
              >
                <h3 className="text-xl font-semibold mb-4 text-slate-800 font-display">
                  {category.title}
                </h3>
                <ul className="space-y-2">
                  {category.skills.map((skill) => (
                    <li key={skill} className="flex items-center gap-3 text-slate-700 font-sans">
                      <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                      {skill}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="max-w-3xl mx-auto text-center"
        >
          <div className="glass-card p-8 border-l-4 border-accent">
            <p className="text-lg text-slate-700 font-sans italic leading-relaxed">
              My strongest edge lies in execution-driven social media systems and AI-integrated marketing workflows.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
