'use client'

import { motion } from 'framer-motion'
import { Sparkles, BarChart3, Zap, Workflow } from 'lucide-react'

const capabilities = [
  {
    icon: Sparkles,
    title: 'Content Ideation Acceleration',
    description: 'Using AI to generate diverse content angles, headlines, and campaign concepts at scale. Transform a single brief into dozens of execution-ready variations.',
    gradient: 'from-violet-500 to-accent',
  },
  {
    icon: BarChart3,
    title: 'Campaign Performance Analysis',
    description: 'Leverage AI-powered analytics to identify patterns in audience behavior, optimal posting times, and content types that drive engagement and conversions.',
    gradient: 'from-accent to-blue-600',
  },
  {
    icon: Workflow,
    title: 'Dashboard-Driven Insights',
    description: 'Build Power BI dashboards that integrate AI predictions with real-time marketing data, enabling faster decision-making and strategic pivots.',
    gradient: 'from-blue-600 to-slate-700',
  },
  {
    icon: Zap,
    title: 'Workflow Automation',
    description: 'Design intelligent automation systems for content distribution, audience segmentation, and personalized messaging across multiple platforms.',
    gradient: 'from-slate-700 to-accent',
  },
]

export default function AIIntegration() {
  return (
    <section className="py-32 bg-gradient-to-b from-white to-slate-50">
      <div className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <h2 className="text-5xl md:text-6xl font-light mb-4 text-slate-900">
            How I Use AI in Marketing
          </h2>
          <p className="text-lg text-slate-600 font-sans max-w-2xl mx-auto">
            Artificial intelligence isn&apos;t just a tool—it&apos;s a force multiplier for strategic marketing execution
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
          {capabilities.map((capability, index) => {
            const Icon = capability.icon
            
            return (
              <motion.div
                key={capability.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -4 }}
                className="group relative"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${capability.gradient} opacity-0 group-hover:opacity-5 rounded-3xl blur-xl transition-opacity duration-500`} />
                
                <div className="relative glass-card p-8 h-full hover:border-accent/30 transition-all duration-300">
                  <div className={`inline-flex p-4 rounded-2xl bg-gradient-to-br ${capability.gradient} mb-6`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>

                  <h3 className="text-2xl font-semibold text-slate-900 mb-4 font-display">
                    {capability.title}
                  </h3>
                  <p className="text-slate-600 font-sans leading-relaxed">
                    {capability.description}
                  </p>
                </div>
              </motion.div>
            )
          })}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-16 text-center"
        >
          <div className="inline-flex items-center gap-3 glass-card px-8 py-4 rounded-full">
            <Sparkles className="w-5 h-5 text-accent" />
            <p className="font-sans text-slate-700">
              Combining human strategy with machine intelligence for maximum impact
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
