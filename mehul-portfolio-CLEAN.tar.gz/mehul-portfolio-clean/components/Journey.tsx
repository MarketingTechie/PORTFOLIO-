'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronDown, Award, Briefcase, TrendingUp } from 'lucide-react'

interface Milestone {
  year: string
  title: string
  description: string
  impact: string
  icon: any
  color: string
}

const milestones: Milestone[] = [
  {
    year: '2021',
    title: 'Built & Scaled Motivation Instagram Page',
    description: 'Created and grew a motivation-themed Instagram page from zero to 500+ engaged followers',
    impact: 'Developed deep understanding of content psychology, posting schedules, and audience engagement mechanics. Experimented with visual storytelling and caption frameworks that drive action.',
    icon: TrendingUp,
    color: 'from-blue-500 to-accent',
  },
  {
    year: '2021',
    title: 'Co-Founded Social Media Management Initiative',
    description: 'Launched a collaborative social media management service for small businesses',
    impact: 'Learned client management, content calendars, multi-platform strategy, and performance reporting. Built systems for consistent delivery and measurable results.',
    icon: Briefcase,
    color: 'from-accent to-blue-600',
  },
  {
    year: 'Certifications',
    title: 'Industry-Recognized Training',
    description: 'HubSpot Digital Marketing • SEMrush AI-Powered Marketer • Power BI Marketing Dashboards',
    impact: 'Validated expertise in digital marketing fundamentals, AI-driven campaign optimization, and data visualization for marketing KPIs. Demonstrates commitment to continuous learning in a rapidly evolving field.',
    icon: Award,
    color: 'from-blue-700 to-slate-700',
  },
  {
    year: 'Recent',
    title: 'Digital Marketing Internship at BoloSuno',
    description: 'Executed LinkedIn campaigns and refined brand positioning strategy',
    impact: 'Gained hands-on experience with B2B social media, professional content creation, and strategic brand messaging. Contributed to improving brand visibility and engagement metrics.',
    icon: TrendingUp,
    color: 'from-accent to-blue-500',
  },
]

export default function Journey() {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null)

  const toggleMilestone = (index: number) => {
    setExpandedIndex(expandedIndex === index ? null : index)
  }

  return (
    <section className="py-32 bg-white">
      <div className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <h2 className="text-5xl md:text-6xl font-light mb-4 text-slate-900">
            Strategic Journey
          </h2>
          <p className="text-lg text-slate-600 font-sans">
            Key milestones in building a modern marketing skillset
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <div className="relative">
            <div className="absolute left-8 top-0 bottom-0 w-px bg-gradient-to-b from-slate-200 via-accent/30 to-slate-200" />

            <div className="space-y-6">
              {milestones.map((milestone, index) => {
                const Icon = milestone.icon
                const isExpanded = expandedIndex === index

                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    className="relative pl-20"
                  >
                    <motion.div
                      className={`absolute left-0 w-16 h-16 rounded-2xl bg-gradient-to-br ${milestone.color} flex items-center justify-center soft-shadow`}
                      whileHover={{ scale: 1.05 }}
                      transition={{ type: "spring", stiffness: 300 }}
                    >
                      <Icon className="w-7 h-7 text-white" />
                    </motion.div>

                    <motion.div
                      className="glass-card overflow-hidden cursor-pointer"
                      onClick={() => toggleMilestone(index)}
                      whileHover={{ scale: 1.01 }}
                      transition={{ type: "spring", stiffness: 300 }}
                    >
                      <div className="p-6">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <span className="font-mono text-sm font-medium text-accent">
                                {milestone.year}
                              </span>
                            </div>
                            <h3 className="text-xl font-semibold text-slate-900 mb-2 font-display">
                              {milestone.title}
                            </h3>
                            <p className="text-slate-600 font-sans leading-relaxed">
                              {milestone.description}
                            </p>
                          </div>
                          <motion.div
                            animate={{ rotate: isExpanded ? 180 : 0 }}
                            transition={{ duration: 0.3 }}
                          >
                            <ChevronDown className="w-5 h-5 text-slate-400 flex-shrink-0" />
                          </motion.div>
                        </div>

                        <AnimatePresence>
                          {isExpanded && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.3 }}
                              className="overflow-hidden"
                            >
                              <div className="mt-4 pt-4 border-t border-slate-200">
                                <p className="text-sm font-semibold text-slate-700 mb-2 font-sans">
                                  Impact & Learning:
                                </p>
                                <p className="text-slate-600 font-sans leading-relaxed">
                                  {milestone.impact}
                                </p>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    </motion.div>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
