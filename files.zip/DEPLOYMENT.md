# Deployment Guide

## Quick Deploy to Vercel (Recommended)

### Method 1: GitHub + Vercel Dashboard
1. **Push to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Premium portfolio"
   git branch -M main
   git remote add origin <your-github-repo-url>
   git push -u origin main
   ```

2. **Connect to Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Click "New Project"
   - Import your GitHub repository
   - Vercel auto-detects Next.js settings
   - Click "Deploy"
   - Done! Your site is live in ~2 minutes

### Method 2: Vercel CLI (Fastest)
```bash
npm install -g vercel
cd mehul-portfolio
vercel
```
Follow the prompts. Your site will be deployed instantly.

## Local Development

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Open http://localhost:3000
```

## Production Build (Test Locally)

```bash
# Create optimized production build
npm run build

# Start production server
npm start

# Open http://localhost:3000
```

## Environment Variables

This portfolio doesn't require any environment variables by default. If you add features that need them:

1. Create `.env.local` in the project root
2. Add your variables:
   ```
   NEXT_PUBLIC_ANALYTICS_ID=your_id_here
   ```
3. Access in code: `process.env.NEXT_PUBLIC_ANALYTICS_ID`

**Note**: `.env.local` is gitignored and won't be committed.

## Custom Domain Setup

After deploying to Vercel:

1. Go to your project in Vercel Dashboard
2. Navigate to "Settings" → "Domains"
3. Add your custom domain
4. Follow DNS configuration instructions
5. Vercel auto-provisions SSL certificate

## Performance Tips

- **Already Optimized**: Fonts, images, and code splitting are handled automatically
- **CDN**: Vercel deploys to global edge network
- **Analytics**: Add Vercel Analytics in project settings for performance insights

## Troubleshooting

### Build Fails
- Ensure Node.js version is 18 or higher
- Delete `node_modules` and `.next` folders, then run `npm install`

### Styles Not Loading
- Verify `tailwind.config.js` content paths are correct
- Check that `globals.css` imports Tailwind directives

### Animations Laggy
- This usually indicates low-end device or browser
- Animations are CSS/GPU-accelerated for best performance

## Post-Deployment Checklist

- [ ] Update social media links in `components/Footer.tsx`
- [ ] Replace email placeholder with real email
- [ ] Test on mobile devices
- [ ] Check accessibility with Lighthouse
- [ ] Set up analytics (optional)
- [ ] Configure custom domain (optional)

## Updates & Maintenance

To update your live site:
```bash
# Make changes locally
git add .
git commit -m "Update content"
git push

# Vercel auto-deploys on push to main branch
```

---

**Need Help?**
- Vercel Docs: [vercel.com/docs](https://vercel.com/docs)
- Next.js Docs: [nextjs.org/docs](https://nextjs.org/docs)
