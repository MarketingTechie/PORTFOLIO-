# Mehul Panicker - Portfolio Website

A premium, minimalist portfolio website for an AI-driven digital marketer, built with modern web technologies and refined design principles.

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **Animations**: Framer Motion
- **Charts**: Recharts
- **Icons**: Lucide React
- **Deployment**: Vercel-ready

## Design Philosophy

This portfolio embodies executive minimalism with:
- Off-white (cream) background for warmth
- Muted blue accent color for professionalism
- Elegant typography (Cormorant Garamond + Work Sans)
- Soft shadows and glass-morphism effects
- Generous whitespace and clean grid layouts
- Subtle, purposeful animations

## Features

### 1. Hero Section
- Large, elegant typography
- Animated background elements
- Smooth scroll CTA to capabilities

### 2. Core Expertise
- Visual radar chart mapping skill strengths
- Categorized skill breakdown
- Key insight callout

### 3. Strategic Journey
- Interactive vertical timeline
- Expandable milestone cards
- Visual icons for each achievement

### 4. AI Integration
- Four key capability cards
- Gradient backgrounds and hover effects
- Strategic positioning of AI tools in marketing workflow

### 5. Footer
- Minimal tagline
- Social media links
- Refined dark theme

## Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone <your-repo-url>
cd mehul-portfolio
```

2. Install dependencies:
```bash
npm install
# or
yarn install
```

3. Run the development server:
```bash
npm run dev
# or
yarn dev
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Deployment to Vercel

This project is optimized for Vercel deployment:

### Option 1: Deploy via Vercel Dashboard
1. Push your code to GitHub
2. Visit [vercel.com](https://vercel.com)
3. Import your repository
4. Vercel will auto-detect Next.js and configure everything
5. Click "Deploy"

### Option 2: Deploy via Vercel CLI
```bash
npm install -g vercel
vercel
```

## Customization

### Colors
Edit `tailwind.config.js` to modify the color palette:
```js
colors: {
  cream: '#FAFAF8',
  accent: '#4F7CAC',
  // ... other colors
}
```

### Fonts
Fonts are configured in `app/layout.tsx`:
- Display: Cormorant Garamond
- Body: Work Sans
- Mono: JetBrains Mono

### Content
Update content in component files:
- Hero: `components/Hero.tsx`
- Skills: `components/Expertise.tsx`
- Timeline: `components/Journey.tsx`
- AI Capabilities: `components/AIIntegration.tsx`
- Footer: `components/Footer.tsx`

### Social Links
Update social media links in `components/Footer.tsx`:
```tsx
const socialLinks = [
  { icon: Mail, href: 'mailto:your@email.com', label: 'Email' },
  { icon: Linkedin, href: 'https://linkedin.com/in/yourprofile', label: 'LinkedIn' },
  // ...
]
```

## Project Structure

```
mehul-portfolio/
├── app/
│   ├── layout.tsx          # Root layout with fonts
│   ├── page.tsx            # Main page
│   └── globals.css         # Global styles
├── components/
│   ├── Hero.tsx            # Hero section
│   ├── Expertise.tsx       # Skills radar chart
│   ├── Journey.tsx         # Timeline
│   ├── AIIntegration.tsx   # AI capabilities
│   └── Footer.tsx          # Footer
├── public/                 # Static assets
├── package.json
├── tsconfig.json
├── tailwind.config.js
├── postcss.config.js
├── next.config.js
└── README.md
```

## Performance Optimizations

- Font optimization via Next.js font system
- Automatic image optimization
- Server-side rendering
- Code splitting
- CSS purging via Tailwind

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## License

© 2026 Mehul Panicker. All rights reserved.

---

**Built with precision. Designed for impact.**
